import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { createDigitalTwinOrchestrator, groupJpbRows, validateJpbBatchGroups } from '../src/index.js';

const cleanupPaths: string[] = [];

afterEach(async () => {
  await Promise.all(cleanupPaths.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});

const input = {
  affaire: [
    {
      NAF: '44671',
      PARTNUMBER: 'ST5363-07',
      MODELE: '21',
      DESA: 'LULYLOK',
      QTEAF: '500.000000',
      DATEAF: '2023-10-09',
      DDP: '2024-06-19',
      DELAI: '2024-03-01',
      ETATAF: 'S',
    },
  ],
  gamme: [
    {
      NAF: '44671',
      RANG: '001',
      PARTNUMBER: 'ST5363-07',
      PHASE: '50',
      GA_DES: 'Sabler',
      COFRAIS: 'SABL',
      GA_PREP: '0.333333',
      GA_NBH: '5.555500',
    },
  ],
  point: [
    {
      IDPOINT: '246474',
      CODEEMP: 'XAV',
      TPSPASSE: '0.116667',
      DAT: '2024-03-05',
      COFRAIS: '1CTRL',
      NAF: '44671',
      NBPIE: '18.000000',
      NBPIEABIME: '0.000000',
      DATEFIN: '2024-03-05',
      HEUREDEB: '19:00:00',
      HEUREFIN: '19:07:00',
    },
  ],
  cfrais: [
    { IDCFRAIS: '156', COFRAIS: 'SABL', DESIGN: 'SABLAGE & MASQUAGE' },
    { IDCFRAIS: '62', COFRAIS: '1CTRL', DESIGN: '1ERE PIÈCE CONTRÔLE' },
  ],
};

describe('JPB orchestrator', () => {
  it('groups raw rows into production-item envelopes', () => {
    const groups = groupJpbRows(input);

    expect(groups).toHaveLength(1);
    expect(groups[0]).toMatchObject({
      orderNo: '44671',
      partNumbers: ['ST5363-07'],
    });
    expect(groups[0]?.routingDefinitions).toHaveLength(1);
    expect(groups[0]?.productionSteps).toHaveLength(1);
    expect(groups[0]?.operationCodes.map((row) => row.COFRAIS).sort()).toEqual(['1CTRL', 'SABL']);
  });

  it('validates grouped batches and reports missing references', () => {
    const warnings = validateJpbBatchGroups(groupJpbRows({ ...input, cfrais: [] }));
    expect(warnings).toContain('Missing CFRAIS operation definition for code SABL on order 44671');
    expect(warnings).toContain('Missing CFRAIS operation definition for code 1CTRL on order 44671');
  });

  it('ingests, queries, and publishes through the orchestrator API', async () => {
    const share = vi.fn(async () => ({ shareOperationId: 'swm-jpb-orch' }));
    const lift = vi.fn(async () => 'job-jpb-1');
    const query = vi.fn(async () => ({ bindings: [{ subject: 'urn:dmaast:jpb:production-item:44671' }] }));
    const orchestrator = createDigitalTwinOrchestrator({
      sharedMemoryPublisher: { share },
      asyncLiftPublisher: { lift },
    });

    const ingested = await orchestrator.ingestJpbBatchToWorkingMemory(input, {
      dataset: 'jpb',
      contextGraphId: 'jpb-demo',
      publisherPeerId: 'peer-jpb',
    });
    expect(ingested.shareOperationId).toBe('swm-jpb-orch');
    expect(ingested.groupedItems).toHaveLength(1);
    expect(ingested.warnings).toEqual([]);

    const queried = await orchestrator.queryProductionItem(
      { orderNo: '44671' },
      {
        dataset: 'jpb',
        graphIri: 'did:dkg:context-graph:jpb/_workspace',
        runner: { query },
      },
    );
    expect(query).toHaveBeenCalledOnce();
    expect(queried.orderNo).toBe('44671');
    expect(queried.sparql).toContain('<https://dmaast.eu/ontology/orderNo> "44671"');

    const published = await orchestrator.publishJpbBatch(input, {
      dataset: 'jpb',
      contextGraphId: 'jpb-demo',
      publisherPeerId: 'peer-jpb',
      swmId: 'swm-jpb',
      namespace: 'manufacturing',
      scope: 'jpb-batch',
      transitionType: 'CREATE',
      authority: { type: 'owner', proofRef: 'proof:jpb:1' },
    });
    expect(lift).toHaveBeenCalledWith({
      swmId: 'swm-jpb',
      shareOperationId: 'swm-jpb-orch',
      roots: ['urn:dmaast:jpb:production-item:44671', 'urn:dmaast:jpb:operation-code:SABL', 'urn:dmaast:jpb:operation-code:1CTRL'],
      contextGraphId: 'jpb-demo',
      namespace: 'manufacturing',
      scope: 'jpb-batch',
      transitionType: 'CREATE',
      authority: { type: 'owner', proofRef: 'proof:jpb:1' },
      priorVersion: undefined,
    });
    expect(published.jobId).toBe('job-jpb-1');
  });

  it('ingests JPB CSV exports through the orchestrator convenience API', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'jpb-orch-'));
    cleanupPaths.push(dir);
    await writeFile(join(dir, 'AFFAIRE.csv'), '"NAF","PARTNUMBER","DESA","ETATAF"\n"44671","ST5363-07","LULYLOK","S"\n');
    await writeFile(join(dir, 'GAMME.csv'), '"NAF","PARTNUMBER","PHASE","COFRAIS"\n"44671","ST5363-07","50","SABL"\n');
    await writeFile(join(dir, 'POINT.csv'), '"IDPOINT","NAF","COFRAIS"\n"246474","44671","SABL"\n');
    await writeFile(join(dir, 'CFRAIS.csv'), '"IDCFRAIS","COFRAIS","DESIGN"\n"156","SABL","SABLAGE & MASQUAGE"\n');

    const share = vi.fn(async () => ({ shareOperationId: 'swm-csv-1' }));
    const orchestrator = createDigitalTwinOrchestrator({
      sharedMemoryPublisher: { share },
    });

    const result = await orchestrator.ingestJpbCsvExports(
      {
        affaire: join(dir, 'AFFAIRE.csv'),
        gamme: join(dir, 'GAMME.csv'),
        point: join(dir, 'POINT.csv'),
        cfrais: join(dir, 'CFRAIS.csv'),
      },
      {
        dataset: 'jpb',
        contextGraphId: 'jpb-demo',
        publisherPeerId: 'peer-jpb',
      },
    );

    expect(share).toHaveBeenCalledOnce();
    expect(result.shareOperationId).toBe('swm-csv-1');
    expect(result.groupedItems).toHaveLength(1);
    expect(result.warnings).toEqual([]);
  });
});
