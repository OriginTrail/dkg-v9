import { describe, expect, it, vi } from 'vitest';
import { buildAssetWith, createLiftRequest, defineAssetBuilder, liftAssetsWith, shareAssetsWith } from '../src/index.js';

describe('digital-twin async lift wiring', () => {
  it('builds assets through the package helper', async () => {
    const builder = defineAssetBuilder<Record<string, unknown>>({
      build(node, context) {
        return {
          rootEntity: String(node['@id']),
          quads: [
            {
              subject: String(node['@id']),
              predicate: 'http://schema.org/name',
              object: JSON.stringify(`${context.dataset}:${String(node.name)}`),
            },
          ],
        };
      },
    });

    await expect(
      buildAssetWith(builder, { '@id': 'urn:test:item-1', name: 'Mixer' }, { dataset: 'machines', contextGraphId: 'cg-1' }),
    ).resolves.toEqual({
      rootEntity: 'urn:test:item-1',
      quads: [
        {
          subject: 'urn:test:item-1',
          predicate: 'http://schema.org/name',
          object: '"machines:Mixer"',
        },
      ],
    });
  });

  it('shares mapped assets and derives lift requests', async () => {
    const share = vi.fn(async () => ({ shareOperationId: 'swm-op-1' }));
    const shared = await shareAssetsWith(
      { share },
      [
        {
          rootEntity: 'urn:test:item-1',
          quads: [
            {
              subject: 'urn:test:item-1',
              predicate: 'http://schema.org/name',
              object: '"Mixer"',
            },
          ],
        },
      ],
      { contextGraphId: 'cg-1', publisherPeerId: 'peer-1' },
    );

    expect(share).toHaveBeenCalledWith(
      'cg-1',
      [
        {
          subject: 'urn:test:item-1',
          predicate: 'http://schema.org/name',
          object: '"Mixer"',
          graph: '',
        },
      ],
      { publisherPeerId: 'peer-1', subGraphName: undefined },
    );
    expect(shared).toEqual({
      shareOperationId: 'swm-op-1',
      roots: ['urn:test:item-1'],
      quads: [
        {
          subject: 'urn:test:item-1',
          predicate: 'http://schema.org/name',
          object: '"Mixer"',
          graph: '',
        },
      ],
    });

    expect(
      createLiftRequest(shared, {
        swmId: 'swm-main',
        contextGraphId: 'cg-1',
        namespace: 'manufacturing',
        scope: 'jpb-batch',
        transitionType: 'CREATE',
        authority: { type: 'owner', proofRef: 'proof:1' },
      }),
    ).toEqual({
      swmId: 'swm-main',
      shareOperationId: 'swm-op-1',
      roots: ['urn:test:item-1'],
      contextGraphId: 'cg-1',
      namespace: 'manufacturing',
      scope: 'jpb-batch',
      transitionType: 'CREATE',
      authority: { type: 'owner', proofRef: 'proof:1' },
      priorVersion: undefined,
    });
  });

  it('wires shared-memory publishing into async lift job submission', async () => {
    const share = vi.fn(async () => ({ shareOperationId: 'swm-op-2' }));
    const lift = vi.fn(async () => 'job-1');

    const result = await liftAssetsWith(
      { share },
      { lift },
      [
        {
          rootEntity: 'urn:test:item-1',
          quads: [
            {
              subject: 'urn:test:item-1',
              predicate: 'http://schema.org/name',
              object: '"Mixer"',
            },
          ],
        },
      ],
      {
        dataset: 'machines',
        contextGraphId: 'cg-1',
        swmId: 'swm-main',
        namespace: 'manufacturing',
        scope: 'jpb-batch',
        transitionType: 'CREATE',
        authority: { type: 'owner', proofRef: 'proof:1' },
        publisherPeerId: 'peer-1',
      },
    );

    expect(lift).toHaveBeenCalledWith({
      swmId: 'swm-main',
      shareOperationId: 'swm-op-2',
      roots: ['urn:test:item-1'],
      contextGraphId: 'cg-1',
      namespace: 'manufacturing',
      scope: 'jpb-batch',
      transitionType: 'CREATE',
      authority: { type: 'owner', proofRef: 'proof:1' },
      priorVersion: undefined,
    });
    expect(result.jobId).toBe('job-1');
    expect(result.shareOperationId).toBe('swm-op-2');
  });

  it('rejects assets without a root-matching quad', async () => {
    await expect(
      shareAssetsWith(
        { share: async () => ({ shareOperationId: 'swm-op-3' }) },
        [
          {
            rootEntity: 'urn:test:item-1',
            quads: [
              {
                subject: 'urn:test:item-2',
                predicate: 'http://schema.org/name',
                object: '"Mismatch"',
              },
            ],
          },
        ],
        { contextGraphId: 'cg-1', publisherPeerId: 'peer-1' },
      ),
    ).rejects.toThrow('Digital twin asset urn:test:item-1 must include at least one quad whose subject matches the rootEntity');
  });
});
