import type { Parser, ParseResult, ParserContext } from './types.js';

export function defineParser<TInput, TRow>(parser: Parser<TInput, TRow>): Parser<TInput, TRow> {
  return parser;
}

export function parseWith<TInput, TRow>(
  parser: Parser<TInput, TRow>,
  input: TInput,
  context: ParserContext,
): Promise<ParseResult<TRow>> | ParseResult<TRow> {
  return parser.parse(input, context);
}
