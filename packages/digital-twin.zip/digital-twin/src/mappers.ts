import type { Mapper, MapperContext } from './types.js';

export function defineMapper<TRow, TNode>(mapper: Mapper<TRow, TNode>): Mapper<TRow, TNode> {
  return mapper;
}

export function mapWith<TRow, TNode>(
  mapper: Mapper<TRow, TNode>,
  row: TRow,
  context: MapperContext,
): Promise<TNode> | TNode {
  return mapper.map(row, context);
}
