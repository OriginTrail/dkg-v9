import type {
  AsyncLiftPublisher,
  DigitalTwinAsset,
  DigitalTwinQuad,
  LiftContext,
  LiftRequest,
  LiftedBatch,
  SharedBatch,
  SharedMemoryPublisher,
} from './types.js';

export async function shareAssetsWith(
  publisher: SharedMemoryPublisher,
  assets: readonly DigitalTwinAsset[],
  context: Pick<LiftContext, 'contextGraphId' | 'publisherPeerId' | 'subGraphName'>,
): Promise<SharedBatch> {
  const roots = collectRoots(assets);
  const quads = flattenQuads(assets);

  const result = await publisher.share(context.contextGraphId, quads, {
    publisherPeerId: context.publisherPeerId,
    subGraphName: context.subGraphName,
  });

  return {
    shareOperationId: result.shareOperationId,
    roots,
    quads,
  };
}

export function createLiftRequest(
  shared: SharedBatch,
  context: Pick<
    LiftContext,
    'swmId' | 'contextGraphId' | 'namespace' | 'scope' | 'transitionType' | 'authority' | 'priorVersion'
  >,
): LiftRequest {
  return {
    swmId: context.swmId,
    shareOperationId: shared.shareOperationId,
    roots: shared.roots,
    contextGraphId: context.contextGraphId,
    namespace: context.namespace,
    scope: context.scope,
    transitionType: context.transitionType,
    authority: context.authority,
    priorVersion: context.priorVersion,
  };
}

export async function liftAssetsWith(
  sharedMemoryPublisher: SharedMemoryPublisher,
  asyncLiftPublisher: AsyncLiftPublisher,
  assets: readonly DigitalTwinAsset[],
  context: LiftContext,
): Promise<LiftedBatch> {
  const shared = await shareAssetsWith(sharedMemoryPublisher, assets, context);
  const request = createLiftRequest(shared, context);
  const jobId = await asyncLiftPublisher.lift(request);

  return {
    ...shared,
    jobId,
    request,
  };
}

function collectRoots(assets: readonly DigitalTwinAsset[]): string[] {
  const roots = [...new Set(assets.map((asset) => asset.rootEntity.trim()).filter(Boolean))];
  if (roots.length === 0) {
    throw new Error('Digital twin lift wiring requires at least one asset rootEntity');
  }

  return roots;
}

function flattenQuads(assets: readonly DigitalTwinAsset[]): DigitalTwinQuad[] {
  const quads = assets.flatMap((asset) => asset.quads.map((quad) => ({ ...quad, graph: quad.graph ?? '' })));
  if (quads.length === 0) {
    throw new Error('Digital twin lift wiring requires at least one quad to share');
  }

  for (const asset of assets) {
    if (!asset.quads.some((quad) => quad.subject === asset.rootEntity)) {
      throw new Error(`Digital twin asset ${asset.rootEntity} must include at least one quad whose subject matches the rootEntity`);
    }
  }

  return quads;
}
