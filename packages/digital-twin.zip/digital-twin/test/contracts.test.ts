import { describe, expect, it } from 'vitest';
import { defineMapper, defineParser, definePublisher, defineQuery, mapWith, parseWith, publishWith, runQuery } from '../src/index.js';

describe('digital-twin scaffold contracts', () => {
  it('runs parser and mapper contracts through the package helpers', async () => {
    const parser = defineParser<string, { sourceTable: string; values: Record<string, unknown> }>({
      parse(input, context) {
        return {
          rows: [{ sourceTable: context.dataset, values: { raw: input } }],
        };
      },
    });

    const parsed = await parseWith(parser, 'alpha', { dataset: 'items' });
    expect(parsed.rows).toEqual([{ sourceTable: 'items', values: { raw: 'alpha' } }]);

    const mapper = defineMapper<{ sourceTable: string; values: Record<string, unknown> }, { '@type': string; raw: unknown }>({
      map(row) {
        return {
          '@type': row.sourceTable,
          raw: row.values.raw,
        };
      },
    });

    expect(mapWith(mapper, parsed.rows[0], { dataset: 'items' })).toEqual({
      '@type': 'items',
      raw: 'alpha',
    });
  });

  it('delegates query and publisher contracts with explicit context', async () => {
    const query = defineQuery<{ id: string }>({
      build(params, context) {
        return `SELECT * WHERE { GRAPH <${context.paranetId}> { <${params.id}> ?p ?o } }`;
      },
    });

    const runnerCalls: Array<{ sparql: string; dataset: string; paranetId?: string }> = [];
    const result = await runQuery(
      query,
      { id: 'urn:test:node' },
      {
        async query(sparql, context) {
          runnerCalls.push({ sparql, dataset: context.dataset, paranetId: context.paranetId });
          return { bindings: [] };
        },
      },
      { dataset: 'items', paranetId: 'did:dkg:context-graph:test' },
    );

    expect(result).toEqual({ bindings: [] });
    expect(runnerCalls).toEqual([
      {
        sparql: 'SELECT * WHERE { GRAPH <did:dkg:context-graph:test> { <urn:test:node> ?p ?o } }',
        dataset: 'items',
        paranetId: 'did:dkg:context-graph:test',
      },
    ]);

    const publisher = definePublisher<Record<string, unknown>>({
      async publish(node, options) {
        return {
          ual: String(node['@id']),
          kcId: options?.paranetId ?? 'missing-paranet',
          status: 'published',
        };
      },
    });

    await expect(
      publishWith(
        publisher,
        { '@id': 'urn:test:node', '@type': 'items' },
        { paranetId: 'did:dkg:context-graph:test', accessPolicy: 'public' },
      ),
    ).resolves.toEqual({
      ual: 'urn:test:node',
      kcId: 'did:dkg:context-graph:test',
      status: 'published',
    });
  });
});
