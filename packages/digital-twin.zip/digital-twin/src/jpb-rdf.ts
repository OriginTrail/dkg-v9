import {
  DMAAST_CLASSES,
  DMAAST_EXTERNAL_TERMS,
  DMAAST_PROPERTIES,
} from './dmaast-ontology.js';
import type { DigitalTwinAsset, DigitalTwinQuad } from './types.js';

export interface JpbAffaireRow {
  NAF: string;
  PARTNUMBER: string;
  MODELE?: string;
  DESA?: string;
  QTEAF?: string;
  DATEAF?: string;
  DDP?: string;
  DELAI?: string;
  ETATAF?: string;
}

export interface JpbGammeRow {
  NAF: string;
  PARTNUMBER: string;
  PHASE: string;
  COFRAIS: string;
  GA_DES?: string;
  GA_PREP?: string;
  GA_NBH?: string;
  RANG?: string;
}

export interface JpbPointRow {
  IDPOINT: string;
  NAF: string;
  COFRAIS: string;
  CODEEMP?: string;
  TPSPASSE?: string;
  DAT?: string;
  DATEFIN?: string;
  HEUREDEB?: string;
  HEUREFIN?: string;
  NBPIE?: string;
  NBPIEABIME?: string;
}

export interface JpbCfraisRow {
  IDCFRAIS?: string;
  COFRAIS: string;
  DESIGN?: string;
}

export function mapAffaireRowToAsset(row: JpbAffaireRow): DigitalTwinAsset {
  const rootEntity = productionItemIri(row.NAF);
  return {
    rootEntity,
    quads: compact([
      quad(rootEntity, DMAAST_EXTERNAL_TERMS.rdfType, DMAAST_CLASSES.productionItem),
      quad(rootEntity, DMAAST_PROPERTIES.orderNo, literal(row.NAF)),
      quad(rootEntity, DMAAST_PROPERTIES.partNo, literal(row.PARTNUMBER)),
      quadIfPresent(rootEntity, DMAAST_PROPERTIES.productFamily, row.MODELE),
      quadIfPresent(rootEntity, DMAAST_EXTERNAL_TERMS.schemaDescription, row.DESA),
      quadIfDecimal(rootEntity, DMAAST_PROPERTIES.orderedQuantity, row.QTEAF),
      quadIfDate(rootEntity, DMAAST_PROPERTIES.orderDate, row.DATEAF),
      quadIfDate(rootEntity, DMAAST_PROPERTIES.requestedDeliveryDate, row.DDP),
      quadIfDate(rootEntity, DMAAST_PROPERTIES.productionDeadline, row.DELAI),
      quadIfPresent(rootEntity, DMAAST_PROPERTIES.orderStatus, row.ETATAF),
    ]),
  };
}

export function mapGammeRowToAsset(row: JpbGammeRow): DigitalTwinAsset {
  const rootEntity = productionItemIri(row.NAF);
  const routing = routingDefinitionIri(row.NAF, row.PHASE, row.COFRAIS);
  return {
    rootEntity,
    quads: compact([
      quad(rootEntity, DMAAST_PROPERTIES.orderNo, literal(row.NAF)),
      quad(rootEntity, DMAAST_PROPERTIES.partNo, literal(row.PARTNUMBER)),
      quad(rootEntity, DMAAST_PROPERTIES.followsRoutingDefinition, routing),
      quad(routing, DMAAST_EXTERNAL_TERMS.rdfType, DMAAST_CLASSES.routingDefinition),
      quad(routing, DMAAST_PROPERTIES.orderNo, literal(row.NAF)),
      quad(routing, DMAAST_PROPERTIES.partNo, literal(row.PARTNUMBER)),
      quadIfInteger(routing, DMAAST_PROPERTIES.phaseNumber, row.PHASE),
      quad(routing, DMAAST_PROPERTIES.operationCode, literal(row.COFRAIS)),
      quadIfPresent(routing, DMAAST_EXTERNAL_TERMS.schemaDescription, row.GA_DES),
      quadIfDecimal(routing, DMAAST_PROPERTIES.setupTime, row.GA_PREP),
      quadIfDecimal(routing, DMAAST_PROPERTIES.runTime, row.GA_NBH),
      quadIfInteger(routing, DMAAST_PROPERTIES.operationSequence, row.RANG),
    ]),
  };
}

export function mapPointRowToAsset(row: JpbPointRow): DigitalTwinAsset {
  const rootEntity = productionItemIri(row.NAF);
  const step = productionStepIri(row.IDPOINT);
  return {
    rootEntity,
    quads: compact([
      quad(rootEntity, DMAAST_PROPERTIES.orderNo, literal(row.NAF)),
      quad(rootEntity, DMAAST_PROPERTIES.hasProductionStep, step),
      quad(step, DMAAST_EXTERNAL_TERMS.rdfType, DMAAST_CLASSES.productionStepEvent),
      quad(step, DMAAST_PROPERTIES.eventId, literal(row.IDPOINT)),
      quad(step, DMAAST_PROPERTIES.orderNo, literal(row.NAF)),
      quad(step, DMAAST_PROPERTIES.operationCode, literal(row.COFRAIS)),
      quadIfPresent(step, DMAAST_PROPERTIES.operatorId, row.CODEEMP),
      quadIfDecimal(step, DMAAST_PROPERTIES.duration, row.TPSPASSE),
      quadIfDate(step, DMAAST_PROPERTIES.eventDate, row.DAT),
      quadIfDate(step, DMAAST_PROPERTIES.endDate, row.DATEFIN),
      quadIfTime(step, DMAAST_PROPERTIES.startTime, row.HEUREDEB),
      quadIfTime(step, DMAAST_PROPERTIES.endTime, row.HEUREFIN),
      quadIfDecimal(step, DMAAST_PROPERTIES.itemsProduced, row.NBPIE),
      quadIfDecimal(step, DMAAST_PROPERTIES.itemsDamaged, row.NBPIEABIME),
      quad(step, DMAAST_PROPERTIES.usesOperationCode, operationCodeIri(row.COFRAIS)),
    ]),
  };
}

export function mapCfraisRowToAsset(row: JpbCfraisRow): DigitalTwinAsset {
  const rootEntity = operationCodeIri(row.COFRAIS);
  return {
    rootEntity,
    quads: compact([
      quad(rootEntity, DMAAST_EXTERNAL_TERMS.rdfType, DMAAST_CLASSES.operationCode),
      quad(rootEntity, DMAAST_PROPERTIES.operationCode, literal(row.COFRAIS)),
      quadIfPresent(rootEntity, DMAAST_EXTERNAL_TERMS.schemaName, row.DESIGN),
      quadIfPresent(rootEntity, DMAAST_PROPERTIES.eventId, row.IDCFRAIS),
    ]),
  };
}

function productionItemIri(orderNo: string): string {
  return `urn:dmaast:jpb:production-item:${encodeURIComponent(orderNo.trim())}`;
}

function routingDefinitionIri(orderNo: string, phase: string, operationCode: string): string {
  return `urn:dmaast:jpb:routing:${encodeURIComponent(orderNo.trim())}:${encodeURIComponent(phase.trim())}:${encodeURIComponent(operationCode.trim())}`;
}

function productionStepIri(eventId: string): string {
  return `urn:dmaast:jpb:production-step:${encodeURIComponent(eventId.trim())}`;
}

function operationCodeIri(operationCode: string): string {
  return `urn:dmaast:jpb:operation-code:${encodeURIComponent(operationCode.trim())}`;
}

function quad(subject: string, predicate: string, object: string): DigitalTwinQuad {
  return { subject, predicate, object, graph: '' };
}

function quadIfPresent(subject: string, predicate: string, value: string | undefined): DigitalTwinQuad | null {
  const normalized = value?.trim();
  return normalized ? quad(subject, predicate, literal(normalized)) : null;
}

function quadIfDate(subject: string, predicate: string, value: string | undefined): DigitalTwinQuad | null {
  const normalized = value?.trim();
  return normalized ? quad(subject, predicate, typedLiteral(normalized, 'date')) : null;
}

function quadIfTime(subject: string, predicate: string, value: string | undefined): DigitalTwinQuad | null {
  const normalized = value?.trim();
  return normalized ? quad(subject, predicate, typedLiteral(normalized, 'time')) : null;
}

function quadIfDecimal(subject: string, predicate: string, value: string | undefined): DigitalTwinQuad | null {
  const normalized = value?.trim();
  return normalized ? quad(subject, predicate, typedLiteral(normalized, 'decimal')) : null;
}

function quadIfInteger(subject: string, predicate: string, value: string | undefined): DigitalTwinQuad | null {
  const normalized = value?.trim();
  return normalized ? quad(subject, predicate, typedLiteral(normalized, 'integer')) : null;
}

function literal(value: string): string {
  return JSON.stringify(value);
}

function typedLiteral(value: string, type: 'date' | 'time' | 'decimal' | 'integer'): string {
  return `${JSON.stringify(value)}^^<http://www.w3.org/2001/XMLSchema#${type}>`;
}

function compact(quads: Array<DigitalTwinQuad | null>): DigitalTwinQuad[] {
  return quads.filter((quad): quad is DigitalTwinQuad => quad !== null);
}
