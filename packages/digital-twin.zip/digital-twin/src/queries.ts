import type { Query, QueryContext, QueryRunner } from './types.js';

export function defineQuery<TParams>(query: Query<TParams>): Query<TParams> {
  return query;
}

export function runQuery<TParams, TResult>(
  query: Query<TParams>,
  params: TParams,
  runner: QueryRunner<TResult>,
  context: QueryContext,
): Promise<TResult> {
  return runner.query(query.build(params, context), context);
}
