import type { AssetBuilder, AssetContext, DigitalTwinAsset, DigitalTwinNode } from './types.js';

export function defineAssetBuilder<TNode = DigitalTwinNode>(builder: AssetBuilder<TNode>): AssetBuilder<TNode> {
  return builder;
}

export function buildAssetWith<TNode = DigitalTwinNode>(
  builder: AssetBuilder<TNode>,
  node: TNode,
  context: AssetContext,
): Promise<DigitalTwinAsset> | DigitalTwinAsset {
  return builder.build(node, context);
}
