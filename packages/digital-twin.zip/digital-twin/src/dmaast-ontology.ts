const DMAAST_BASE_IRI = 'https://dmaast.eu/ontology/' as const;
const SCHEMA_BASE_IRI = 'https://schema.org/' as const;
const PROV_BASE_IRI = 'http://www.w3.org/ns/prov#' as const;
const QUDT_BASE_IRI = 'http://qudt.org/schema/qudt/' as const;
const MASON_BASE_IRI = 'http://www.owl-ontologies.com/mason.owl#' as const;
const GR_BASE_IRI = 'http://purl.org/goodrelations/v1#' as const;
const XSD_BASE_IRI = 'http://www.w3.org/2001/XMLSchema#' as const;

type DmaastTermName =
  | 'ValueChainEntity'
  | 'ProductionItem'
  | 'CustomerOrder'
  | 'RoutingDefinition'
  | 'ProductionStepEvent'
  | 'OperationCode'
  | 'ExpertKnowledge'
  | 'orderNo'
  | 'orderStatus'
  | 'partNo'
  | 'productFamily'
  | 'orderedQuantity'
  | 'orderDate'
  | 'requestedDeliveryDate'
  | 'productionDeadline'
  | 'phaseNumber'
  | 'operationCode'
  | 'setupTime'
  | 'runTime'
  | 'operationSequence'
  | 'hasProductionStep'
  | 'eventId'
  | 'operatorId'
  | 'duration'
  | 'eventDate'
  | 'startTime'
  | 'endDate'
  | 'endTime'
  | 'itemsProduced'
  | 'itemsDamaged'
  | 'sourceSystem'
  | 'sourceTable'
  | 'phaseLabel'
  | 'followsRoutingDefinition'
  | 'usesOperationCode'
  | 'confidenceLevel';

export const DMAAST_NAMESPACES = {
  dmaast: DMAAST_BASE_IRI,
  schema: SCHEMA_BASE_IRI,
  prov: PROV_BASE_IRI,
  qudt: QUDT_BASE_IRI,
  mason: MASON_BASE_IRI,
  gr: GR_BASE_IRI,
  xsd: XSD_BASE_IRI,
} as const;

export const DMAAST_CLASSES = {
  valueChainEntity: term('ValueChainEntity'),
  productionItem: term('ProductionItem'),
  customerOrder: term('CustomerOrder'),
  routingDefinition: term('RoutingDefinition'),
  productionStepEvent: term('ProductionStepEvent'),
  operationCode: term('OperationCode'),
  expertKnowledge: term('ExpertKnowledge'),
} as const;

export const DMAAST_PROPERTIES = {
  orderNo: term('orderNo'),
  orderStatus: term('orderStatus'),
  partNo: term('partNo'),
  productFamily: term('productFamily'),
  orderedQuantity: term('orderedQuantity'),
  orderDate: term('orderDate'),
  requestedDeliveryDate: term('requestedDeliveryDate'),
  productionDeadline: term('productionDeadline'),
  phaseNumber: term('phaseNumber'),
  operationCode: term('operationCode'),
  setupTime: term('setupTime'),
  runTime: term('runTime'),
  operationSequence: term('operationSequence'),
  hasProductionStep: term('hasProductionStep'),
  eventId: term('eventId'),
  operatorId: term('operatorId'),
  duration: term('duration'),
  eventDate: term('eventDate'),
  startTime: term('startTime'),
  endDate: term('endDate'),
  endTime: term('endTime'),
  itemsProduced: term('itemsProduced'),
  itemsDamaged: term('itemsDamaged'),
  sourceSystem: term('sourceSystem'),
  sourceTable: term('sourceTable'),
  phaseLabel: term('phaseLabel'),
  followsRoutingDefinition: term('followsRoutingDefinition'),
  usesOperationCode: term('usesOperationCode'),
  confidenceLevel: term('confidenceLevel'),
} as const;

export const DMAAST_EXTERNAL_TERMS = {
  rdfType: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
  schemaDescription: `${SCHEMA_BASE_IRI}description`,
  schemaName: `${SCHEMA_BASE_IRI}name`,
  provWasGeneratedBy: `${PROV_BASE_IRI}wasGeneratedBy`,
  qudtValue: `${QUDT_BASE_IRI}value`,
  masonWorkCenter: `${MASON_BASE_IRI}workCenter`,
} as const;

export const DMAAST_JPB_CORE_MODEL = {
  coreEntity: {
    classIri: DMAAST_CLASSES.productionItem,
    description: 'Central traceable production entity linking order data, routing context, and manufacturing execution.',
    identityKeys: ['NAF', 'PARTNUMBER'],
  },
  datasets: {
    affaire: {
      classIri: DMAAST_CLASSES.productionItem,
      description: 'JPB production item records with order-facing properties extracted from AFFAIRE.',
      keyFields: ['NAF', 'PARTNUMBER', 'ETATAF'],
      attachesTo: DMAAST_CLASSES.productionItem,
    },
    gamme: {
      classIri: DMAAST_CLASSES.routingDefinition,
      description: 'JPB routing and operation definitions attached to the production item.',
      keyFields: ['NAF', 'PARTNUMBER', 'PHASE', 'COFRAIS'],
      attachesTo: DMAAST_CLASSES.productionItem,
    },
    point: {
      classIri: DMAAST_CLASSES.productionStepEvent,
      description: 'JPB execution tracking events attached to the production item manufacturing history.',
      keyFields: ['IDPOINT', 'NAF', 'COFRAIS', 'CODEEMP'],
      attachesTo: DMAAST_CLASSES.productionItem,
    },
    cfrais: {
      classIri: DMAAST_CLASSES.operationCode,
      description: 'JPB operation code catalog extracted from CFRAIS.',
      keyFields: ['IDCFRAIS', 'COFRAIS', 'DESIGN'],
    },
  },
  bridgeKeys: {
    orderNo: DMAAST_PROPERTIES.orderNo,
    partNo: DMAAST_PROPERTIES.partNo,
    operationCode: DMAAST_PROPERTIES.operationCode,
  },
  relations: {
    hasProductionStep: DMAAST_PROPERTIES.hasProductionStep,
    usesOperationCode: DMAAST_PROPERTIES.usesOperationCode,
    followsRoutingDefinition: DMAAST_PROPERTIES.followsRoutingDefinition,
  },
} as const;

export function term(name: DmaastTermName): `${typeof DMAAST_BASE_IRI}${DmaastTermName}` {
  return `${DMAAST_BASE_IRI}${name}`;
}

export function jsonLdContext() {
  return { ...DMAAST_NAMESPACES };
}
