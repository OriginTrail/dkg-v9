import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { afterEach, describe, expect, it } from 'vitest';
import { loadJpbBatchInputFromFiles, parseAffaireCsv, parseCfraisCsv, parseGammeCsv, parsePointCsv } from '../src/index.js';

const cleanupPaths: string[] = [];

afterEach(async () => {
  await Promise.all(cleanupPaths.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});

describe('JPB CSV helpers', () => {
  it('parses JPB CSV text into typed row objects', () => {
    const affaire = parseAffaireCsv('"NAF","PARTNUMBER","DESA"\n"44671","ST5363-07","LULYLOK"\n');
    const gamme = parseGammeCsv('"NAF","PARTNUMBER","PHASE","COFRAIS"\n"44671","ST5363-07","50","SABL"\n');
    const point = parsePointCsv('"IDPOINT","NAF","COFRAIS"\n"246474","44671","1CTRL"\n');
    const cfrais = parseCfraisCsv('"IDCFRAIS","COFRAIS","DESIGN"\n"156","SABL","SABLAGE & MASQUAGE"\n');

    expect(affaire[0]).toEqual({ NAF: '44671', PARTNUMBER: 'ST5363-07', DESA: 'LULYLOK' });
    expect(gamme[0]).toEqual({ NAF: '44671', PARTNUMBER: 'ST5363-07', PHASE: '50', COFRAIS: 'SABL' });
    expect(point[0]).toEqual({ IDPOINT: '246474', NAF: '44671', COFRAIS: '1CTRL' });
    expect(cfrais[0]).toEqual({ IDCFRAIS: '156', COFRAIS: 'SABL', DESIGN: 'SABLAGE & MASQUAGE' });
  });

  it('loads a JPB batch input from CSV files', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'jpb-csv-'));
    cleanupPaths.push(dir);

    const affairePath = join(dir, 'AFFAIRE.csv');
    const gammePath = join(dir, 'GAMME.csv');
    const pointPath = join(dir, 'POINT.csv');
    const cfraisPath = join(dir, 'CFRAIS.csv');

    await writeFile(affairePath, '"NAF","PARTNUMBER","DESA"\n"44671","ST5363-07","LULYLOK"\n');
    await writeFile(gammePath, '"NAF","PARTNUMBER","PHASE","COFRAIS"\n"44671","ST5363-07","50","SABL"\n');
    await writeFile(pointPath, '"IDPOINT","NAF","COFRAIS"\n"246474","44671","1CTRL"\n');
    await writeFile(cfraisPath, '"IDCFRAIS","COFRAIS","DESIGN"\n"156","SABL","SABLAGE & MASQUAGE"\n');

    const input = await loadJpbBatchInputFromFiles({
      affaire: affairePath,
      gamme: gammePath,
      point: pointPath,
      cfrais: cfraisPath,
    });

    expect(input.affaire).toHaveLength(1);
    expect(input.gamme).toHaveLength(1);
    expect(input.point).toHaveLength(1);
    expect(input.cfrais).toHaveLength(1);
    expect(input.affaire?.[0]?.NAF).toBe('44671');
  });
});
