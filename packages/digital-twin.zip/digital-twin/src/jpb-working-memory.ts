import { DMAAST_CLASSES, DMAAST_PROPERTIES } from './dmaast-ontology.js';
import { mapAffaireRowToAsset, mapCfraisRowToAsset, mapGammeRowToAsset, mapPointRowToAsset, type JpbAffaireRow, type JpbCfraisRow, type JpbGammeRow, type JpbPointRow } from './jpb-rdf.js';
import { shareAssetsWith } from './lift.js';
import type { Query, SharedBatch, SharedMemoryPublisher, WorkingMemoryContext, WorkingMemoryQueryContext } from './types.js';

export interface JpbWorkingMemoryInput {
  affaire?: readonly JpbAffaireRow[];
  gamme?: readonly JpbGammeRow[];
  point?: readonly JpbPointRow[];
  cfrais?: readonly JpbCfraisRow[];
}

export interface ProductionItemWorkspaceQueryParams {
  orderNo: string;
}

export async function shareJpbRowsWith(
  publisher: SharedMemoryPublisher,
  input: JpbWorkingMemoryInput,
  context: WorkingMemoryContext,
): Promise<SharedBatch> {
  const assets = buildJpbAssets(input);
  return shareAssetsWith(publisher, assets, context);
}

export function buildJpbAssets(input: JpbWorkingMemoryInput) {
  return [
    ...(input.affaire ?? []).map(mapAffaireRowToAsset),
    ...(input.gamme ?? []).map(mapGammeRowToAsset),
    ...(input.point ?? []).map(mapPointRowToAsset),
    ...(input.cfrais ?? []).map(mapCfraisRowToAsset),
  ];
}

export function defineProductionItemWorkspaceQuery(): Query<ProductionItemWorkspaceQueryParams> {
  return {
    build(params, context: WorkingMemoryQueryContext) {
      const orderNo = JSON.stringify(params.orderNo);
      return `SELECT ?subject ?predicate ?object WHERE {
  GRAPH <${context.graphIri}> {
    {
      ?item a <${DMAAST_CLASSES.productionItem}> ;
            <${DMAAST_PROPERTIES.orderNo}> ${orderNo} ;
            ?predicate ?object .
      BIND(?item AS ?subject)
    }
    UNION
    {
      ?item a <${DMAAST_CLASSES.productionItem}> ;
            <${DMAAST_PROPERTIES.orderNo}> ${orderNo} ;
            <${DMAAST_PROPERTIES.hasProductionStep}> ?step .
      ?step ?predicate ?object .
      BIND(?step AS ?subject)
    }
    UNION
    {
      ?item a <${DMAAST_CLASSES.productionItem}> ;
            <${DMAAST_PROPERTIES.orderNo}> ${orderNo} ;
            <${DMAAST_PROPERTIES.followsRoutingDefinition}> ?routing .
      ?routing ?predicate ?object .
      BIND(?routing AS ?subject)
    }
  }
}`;
    },
  };
}
