import type { PublishOptions, PublishResult, Publisher } from './types.js';

export function definePublisher<TNode>(publisher: Publisher<TNode>): Publisher<TNode> {
  return publisher;
}

export function publishWith<TNode>(
  publisher: Publisher<TNode>,
  node: TNode,
  options?: PublishOptions,
): Promise<PublishResult> {
  return publisher.publish(node, options);
}
