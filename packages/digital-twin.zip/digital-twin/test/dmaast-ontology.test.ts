import { describe, expect, it } from 'vitest';
import {
  DMAAST_CLASSES,
  DMAAST_JPB_CORE_MODEL,
  DMAAST_NAMESPACES,
  DMAAST_PROPERTIES,
  dmaastJsonLdContext,
  dmaastTerm,
} from '../src/index.js';

describe('dmaast ontology', () => {
  it('exports the documented dmaast namespace and core JPB classes', () => {
    expect(DMAAST_NAMESPACES.dmaast).toBe('https://dmaast.eu/ontology/');
    expect(DMAAST_CLASSES.productionItem).toBe('https://dmaast.eu/ontology/ProductionItem');
    expect(DMAAST_CLASSES.routingDefinition).toBe('https://dmaast.eu/ontology/RoutingDefinition');
    expect(DMAAST_CLASSES.productionStepEvent).toBe('https://dmaast.eu/ontology/ProductionStepEvent');
    expect(DMAAST_CLASSES.operationCode).toBe('https://dmaast.eu/ontology/OperationCode');
  });

  it('captures the bridge-key properties shared across JPB batch datasets', () => {
    expect(DMAAST_PROPERTIES.orderNo).toBe(dmaastTerm('orderNo'));
    expect(DMAAST_PROPERTIES.partNo).toBe(dmaastTerm('partNo'));
    expect(DMAAST_PROPERTIES.operationCode).toBe(dmaastTerm('operationCode'));
    expect(DMAAST_JPB_CORE_MODEL.bridgeKeys).toEqual({
      orderNo: 'https://dmaast.eu/ontology/orderNo',
      partNo: 'https://dmaast.eu/ontology/partNo',
      operationCode: 'https://dmaast.eu/ontology/operationCode',
    });
  });

  it('defines dataset-to-class mappings for AFFAIRE, GAMME, POINT, and CFRAIS', () => {
    expect(DMAAST_JPB_CORE_MODEL.coreEntity.classIri).toBe('https://dmaast.eu/ontology/ProductionItem');
    expect(DMAAST_JPB_CORE_MODEL.datasets.affaire.keyFields).toContain('NAF');
    expect(DMAAST_JPB_CORE_MODEL.datasets.affaire.attachesTo).toBe('https://dmaast.eu/ontology/ProductionItem');
    expect(DMAAST_JPB_CORE_MODEL.datasets.gamme.keyFields).toContain('PHASE');
    expect(DMAAST_JPB_CORE_MODEL.datasets.gamme.attachesTo).toBe('https://dmaast.eu/ontology/ProductionItem');
    expect(DMAAST_JPB_CORE_MODEL.datasets.point.keyFields).toContain('IDPOINT');
    expect(DMAAST_JPB_CORE_MODEL.datasets.point.attachesTo).toBe('https://dmaast.eu/ontology/ProductionItem');
    expect(DMAAST_JPB_CORE_MODEL.datasets.cfrais.keyFields).toContain('COFRAIS');
  });

  it('defines explicit relations between the production item and its execution context', () => {
    expect(DMAAST_JPB_CORE_MODEL.relations).toEqual({
      hasProductionStep: 'https://dmaast.eu/ontology/hasProductionStep',
      usesOperationCode: 'https://dmaast.eu/ontology/usesOperationCode',
      followsRoutingDefinition: 'https://dmaast.eu/ontology/followsRoutingDefinition',
    });
  });

  it('provides a reusable JSON-LD context for ETL output', () => {
    expect(dmaastJsonLdContext()).toEqual(DMAAST_NAMESPACES);
  });
});
