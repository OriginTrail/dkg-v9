import { describe, expect, it } from 'vitest';
import {
  DMAAST_CLASSES,
  DMAAST_EXTERNAL_TERMS,
  DMAAST_JPB_CORE_MODEL,
  DMAAST_PROPERTIES,
} from '../src/index.js';

const affaire44671 = {
  NAF: '44671',
  PARTNUMBER: 'ST5363-07',
  MODELE: '21',
  DESA: 'LULYLOK',
  QTEAF: '500.000000',
  DATEAF: '2023-10-09',
  DDP: '2024-06-19',
  DELAI: '2024-03-01',
  ETATAF: 'S',
};

const gamme44671 = {
  NAF: '44671',
  RANG: '001',
  PARTNUMBER: 'ST5363-07',
  PHASE: '50',
  GA_DES: 'Sabler',
  COFRAIS: 'SABL',
  GA_PREP: '0.333333',
  GA_NBH: '5.555500',
};

const point44671 = {
  IDPOINT: '246474',
  CODEEMP: 'XAV',
  TPSPASSE: '0.116667',
  DAT: '2024-03-05',
  COFRAIS: '1CTRL',
  NAF: '44671',
  NBPIE: '18.000000',
  NBPIEABIME: '0.000000',
  DATEFIN: '2024-03-05',
  HEUREDEB: '19:00:00',
  HEUREFIN: '19:07:00',
};

const cfraisCatalog = {
  IDCFRAIS: '156',
  COFRAIS: 'SABL',
  DESIGN: 'SABLAGE & MASQUAGE',
};

describe('dmaast ontology fit against real JPB sample data', () => {
  it('fits AFFAIRE directly onto a production-item shape', () => {
    const productionItem = {
      '@type': DMAAST_CLASSES.productionItem,
      [DMAAST_PROPERTIES.orderNo]: affaire44671.NAF,
      [DMAAST_PROPERTIES.partNo]: affaire44671.PARTNUMBER,
      [DMAAST_PROPERTIES.productFamily]: affaire44671.MODELE,
      [DMAAST_PROPERTIES.orderedQuantity]: affaire44671.QTEAF,
      [DMAAST_PROPERTIES.orderDate]: affaire44671.DATEAF,
      [DMAAST_PROPERTIES.requestedDeliveryDate]: affaire44671.DDP,
      [DMAAST_PROPERTIES.productionDeadline]: affaire44671.DELAI,
      [DMAAST_PROPERTIES.orderStatus]: affaire44671.ETATAF,
      [DMAAST_EXTERNAL_TERMS.schemaDescription]: affaire44671.DESA,
    };

    expect(productionItem[DMAAST_PROPERTIES.orderNo]).toBe('44671');
    expect(productionItem[DMAAST_PROPERTIES.partNo]).toBe('ST5363-07');
    expect(productionItem[DMAAST_EXTERNAL_TERMS.schemaDescription]).toBe('LULYLOK');
  });

  it('fits GAMME and POINT around the same production item', () => {
    const productionItem = {
      '@type': DMAAST_CLASSES.productionItem,
      [DMAAST_PROPERTIES.orderNo]: gamme44671.NAF,
      [DMAAST_PROPERTIES.partNo]: gamme44671.PARTNUMBER,
    };

    const routingDefinition = {
      '@type': DMAAST_CLASSES.routingDefinition,
      [DMAAST_PROPERTIES.orderNo]: gamme44671.NAF,
      [DMAAST_PROPERTIES.partNo]: gamme44671.PARTNUMBER,
      [DMAAST_PROPERTIES.phaseNumber]: gamme44671.PHASE,
      [DMAAST_PROPERTIES.operationCode]: gamme44671.COFRAIS,
      [DMAAST_PROPERTIES.setupTime]: gamme44671.GA_PREP,
      [DMAAST_PROPERTIES.runTime]: gamme44671.GA_NBH,
      [DMAAST_EXTERNAL_TERMS.schemaDescription]: gamme44671.GA_DES,
    };

    const productionStep = {
      '@type': DMAAST_CLASSES.productionStepEvent,
      [DMAAST_PROPERTIES.eventId]: point44671.IDPOINT,
      [DMAAST_PROPERTIES.orderNo]: point44671.NAF,
      [DMAAST_PROPERTIES.operationCode]: point44671.COFRAIS,
      [DMAAST_PROPERTIES.operatorId]: point44671.CODEEMP,
      [DMAAST_PROPERTIES.duration]: point44671.TPSPASSE,
      [DMAAST_PROPERTIES.eventDate]: point44671.DAT,
      [DMAAST_PROPERTIES.endDate]: point44671.DATEFIN,
      [DMAAST_PROPERTIES.startTime]: point44671.HEUREDEB,
      [DMAAST_PROPERTIES.endTime]: point44671.HEUREFIN,
      [DMAAST_PROPERTIES.itemsProduced]: point44671.NBPIE,
      [DMAAST_PROPERTIES.itemsDamaged]: point44671.NBPIEABIME,
    };

    expect(productionItem[DMAAST_PROPERTIES.orderNo]).toBe(routingDefinition[DMAAST_PROPERTIES.orderNo]);
    expect(productionItem[DMAAST_PROPERTIES.orderNo]).toBe(productionStep[DMAAST_PROPERTIES.orderNo]);
    expect(productionItem[DMAAST_PROPERTIES.partNo]).toBe(routingDefinition[DMAAST_PROPERTIES.partNo]);
    expect(routingDefinition[DMAAST_PROPERTIES.partNo]).toBe('ST5363-07');
    expect(productionStep[DMAAST_PROPERTIES.operationCode]).toBe('1CTRL');
  });

  it('fits CFRAIS as the operation-code dictionary used by routing and execution', () => {
    const operationCode = {
      '@type': DMAAST_CLASSES.operationCode,
      [DMAAST_PROPERTIES.operationCode]: cfraisCatalog.COFRAIS,
      [DMAAST_EXTERNAL_TERMS.schemaName]: cfraisCatalog.DESIGN,
    };

    expect(operationCode[DMAAST_PROPERTIES.operationCode]).toBe('SABL');
    expect(operationCode[DMAAST_EXTERNAL_TERMS.schemaName]).toBe('SABLAGE & MASQUAGE');
  });

  it('confirms the current bridge keys are sufficient for the sampled joins', () => {
    expect(DMAAST_JPB_CORE_MODEL.bridgeKeys).toEqual({
      orderNo: DMAAST_PROPERTIES.orderNo,
      partNo: DMAAST_PROPERTIES.partNo,
      operationCode: DMAAST_PROPERTIES.operationCode,
    });

    expect(affaire44671.NAF).toBe(gamme44671.NAF);
    expect(affaire44671.NAF).toBe(point44671.NAF);
    expect(affaire44671.PARTNUMBER).toBe(gamme44671.PARTNUMBER);
    expect(gamme44671.COFRAIS).toBe(cfraisCatalog.COFRAIS);
  });
});
