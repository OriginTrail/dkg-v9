import { readFile } from 'node:fs/promises';
import type { JpbAffaireRow, JpbCfraisRow, JpbGammeRow, JpbPointRow } from './jpb-rdf.js';
import type { JpbWorkingMemoryInput } from './jpb-working-memory.js';

export interface JpbCsvInputFiles {
  affaire?: string;
  gamme?: string;
  point?: string;
  cfrais?: string;
}

export async function loadJpbBatchInputFromFiles(files: JpbCsvInputFiles): Promise<JpbWorkingMemoryInput> {
  return {
    affaire: files.affaire ? parseAffaireCsv(await readCsvFile(files.affaire)) : [],
    gamme: files.gamme ? parseGammeCsv(await readCsvFile(files.gamme)) : [],
    point: files.point ? parsePointCsv(await readCsvFile(files.point)) : [],
    cfrais: files.cfrais ? parseCfraisCsv(await readCsvFile(files.cfrais)) : [],
  };
}

export function parseAffaireCsv(text: string): JpbAffaireRow[] {
  return parseCsvRows(text) as JpbAffaireRow[];
}

export function parseGammeCsv(text: string): JpbGammeRow[] {
  return parseCsvRows(text) as JpbGammeRow[];
}

export function parsePointCsv(text: string): JpbPointRow[] {
  return parseCsvRows(text) as JpbPointRow[];
}

export function parseCfraisCsv(text: string): JpbCfraisRow[] {
  return parseCsvRows(text) as JpbCfraisRow[];
}

async function readCsvFile(path: string): Promise<string> {
  const content = await readFile(path, 'utf8');
  return content.replace(/\u0000/g, '');
}

function parseCsvRows(text: string): Array<Record<string, string>> {
  const lines = text.split(/\r?\n/).filter((line) => line.trim().length > 0);
  if (lines.length === 0) return [];

  const headers = parseCsvLine(lines[0] ?? '');
  return lines.slice(1).map((line) => {
    const values = parseCsvLine(line);
    return Object.fromEntries(headers.map((header, index) => [header, values[index] ?? '']));
  });
}

function parseCsvLine(line: string): string[] {
  const values: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    const next = line[index + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        current += '"';
        index += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === ',' && !inQuotes) {
      values.push(current);
      current = '';
      continue;
    }

    current += char;
  }

  values.push(current);
  return values.map((value) => value.trim());
}
