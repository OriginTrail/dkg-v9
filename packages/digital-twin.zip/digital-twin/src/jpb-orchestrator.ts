import { createLiftRequest } from './lift.js';
import { loadJpbBatchInputFromFiles, type JpbCsvInputFiles } from './jpb-csv.js';
import { buildJpbAssets, defineProductionItemWorkspaceQuery, shareJpbRowsWith, type JpbWorkingMemoryInput } from './jpb-working-memory.js';
import type {
  AsyncLiftPublisher,
  LiftAuthorityProof,
  LiftRequest,
  LiftTransitionType,
  QueryExecutionContext,
  SharedMemoryPublisher,
  SharedBatch,
  WorkingMemoryContext,
} from './types.js';
import type { JpbAffaireRow, JpbCfraisRow, JpbGammeRow, JpbPointRow } from './jpb-rdf.js';

export interface ProductionItemEnvelope {
  orderNo: string;
  partNumbers: string[];
  productionItem: JpbAffaireRow | null;
  routingDefinitions: JpbGammeRow[];
  productionSteps: JpbPointRow[];
  operationCodes: JpbCfraisRow[];
}

export interface WorkingMemoryIngestContext extends WorkingMemoryContext {
  dataset: 'jpb';
  strict?: boolean;
}

export interface WorkingMemoryIngestResult extends SharedBatch {
  groupedItems: ProductionItemEnvelope[];
  assetsWritten: number;
  quadsWritten: number;
  warnings: string[];
}

export interface ProductionItemQueryParams {
  orderNo: string;
}

export interface ProductionItemQueryResult<TResult = unknown> {
  orderNo: string;
  sparql: string;
  result: TResult;
}

export interface PublishJpbBatchContext extends WorkingMemoryIngestContext {
  swmId: string;
  namespace: string;
  scope: string;
  transitionType: LiftTransitionType;
  authority: LiftAuthorityProof;
  priorVersion?: string;
}

export interface PublishJpbBatchResult extends WorkingMemoryIngestResult {
  jobId: string;
  request: LiftRequest;
}

export interface DigitalTwinOrchestrator {
  ingestJpbCsvExports(
    files: JpbCsvInputFiles,
    context: WorkingMemoryIngestContext,
  ): Promise<WorkingMemoryIngestResult>;
  ingestJpbBatchToWorkingMemory(
    input: JpbWorkingMemoryInput,
    context: WorkingMemoryIngestContext,
  ): Promise<WorkingMemoryIngestResult>;
  queryProductionItem<TResult = unknown>(
    params: ProductionItemQueryParams,
    context: QueryExecutionContext<TResult>,
  ): Promise<ProductionItemQueryResult<TResult>>;
  publishJpbBatch(
    input: JpbWorkingMemoryInput,
    context: PublishJpbBatchContext,
  ): Promise<PublishJpbBatchResult>;
}

export function createDigitalTwinOrchestrator(deps: {
  sharedMemoryPublisher: SharedMemoryPublisher;
  asyncLiftPublisher?: AsyncLiftPublisher;
}): DigitalTwinOrchestrator {
  return {
    async ingestJpbCsvExports(files, context) {
      const input = await loadJpbBatchInputFromFiles(files);
      return this.ingestJpbBatchToWorkingMemory(input, context);
    },

    async ingestJpbBatchToWorkingMemory(input, context) {
      const groupedItems = groupJpbRows(input);
      const warnings = validateJpbBatchGroups(groupedItems);
      if (context.strict && warnings.length > 0) {
        throw new Error(`JPB batch validation failed: ${warnings.join('; ')}`);
      }

      const shared = await shareJpbRowsWith(deps.sharedMemoryPublisher, input, context);
      const assets = buildJpbAssets(input);

      return {
        ...shared,
        groupedItems,
        assetsWritten: assets.length,
        quadsWritten: shared.quads.length,
        warnings,
      };
    },

    async queryProductionItem(params, context) {
      const query = defineProductionItemWorkspaceQuery();
      const sparql = query.build(params, context);
      const result = await context.runner.query(sparql, context);
      return {
        orderNo: params.orderNo,
        sparql,
        result,
      };
    },

    async publishJpbBatch(input, context) {
      if (!deps.asyncLiftPublisher) {
        throw new Error('Digital twin publishJpbBatch requires an asyncLiftPublisher dependency');
      }

      const ingested = await this.ingestJpbBatchToWorkingMemory(input, context);
      const request = createLiftRequest(ingested, context);
      const jobId = await deps.asyncLiftPublisher.lift(request);
      return {
        ...ingested,
        jobId,
        request,
      };
    },
  };
}

export function groupJpbRows(input: JpbWorkingMemoryInput): ProductionItemEnvelope[] {
  const groups = new Map<string, ProductionItemEnvelope>();
  const cfraisByCode = new Map((input.cfrais ?? []).map((row) => [row.COFRAIS, row]));

  for (const row of input.affaire ?? []) {
    const group = ensureGroup(groups, row.NAF);
    group.productionItem = row;
    addPartNumber(group, row.PARTNUMBER);
  }

  for (const row of input.gamme ?? []) {
    const group = ensureGroup(groups, row.NAF);
    group.routingDefinitions.push(row);
    addPartNumber(group, row.PARTNUMBER);
    maybeAddOperationCode(group, cfraisByCode.get(row.COFRAIS));
  }

  for (const row of input.point ?? []) {
    const group = ensureGroup(groups, row.NAF);
    group.productionSteps.push(row);
    maybeAddOperationCode(group, cfraisByCode.get(row.COFRAIS));
  }

  return [...groups.values()].sort((a, b) => a.orderNo.localeCompare(b.orderNo));
}

export function validateJpbBatchGroups(groups: readonly ProductionItemEnvelope[]): string[] {
  const warnings: string[] = [];
  for (const group of groups) {
    if (!group.productionItem) {
      warnings.push(`Missing AFFAIRE row for order ${group.orderNo}`);
    }
    if (group.routingDefinitions.length === 0) {
      warnings.push(`Missing GAMME routing rows for order ${group.orderNo}`);
    }
    if (group.productionSteps.length === 0) {
      warnings.push(`Missing POINT execution rows for order ${group.orderNo}`);
    }
    if (group.partNumbers.length > 1) {
      warnings.push(`Multiple part numbers found for order ${group.orderNo}: ${group.partNumbers.join(', ')}`);
    }

    const referencedCodes = new Set([
      ...group.routingDefinitions.map((row) => row.COFRAIS),
      ...group.productionSteps.map((row) => row.COFRAIS),
    ]);
    const attachedCodes = new Set(group.operationCodes.map((row) => row.COFRAIS));
    for (const code of referencedCodes) {
      if (!attachedCodes.has(code)) {
        warnings.push(`Missing CFRAIS operation definition for code ${code} on order ${group.orderNo}`);
      }
    }
  }
  return warnings;
}

function ensureGroup(groups: Map<string, ProductionItemEnvelope>, orderNo: string): ProductionItemEnvelope {
  const existing = groups.get(orderNo);
  if (existing) return existing;

  const created: ProductionItemEnvelope = {
    orderNo,
    partNumbers: [],
    productionItem: null,
    routingDefinitions: [],
    productionSteps: [],
    operationCodes: [],
  };
  groups.set(orderNo, created);
  return created;
}

function addPartNumber(group: ProductionItemEnvelope, partNumber: string | undefined) {
  const normalized = partNumber?.trim();
  if (normalized && !group.partNumbers.includes(normalized)) {
    group.partNumbers.push(normalized);
  }
}

function maybeAddOperationCode(group: ProductionItemEnvelope, row: JpbCfraisRow | undefined) {
  if (!row) return;
  if (!group.operationCodes.some((candidate) => candidate.COFRAIS === row.COFRAIS)) {
    group.operationCodes.push(row);
  }
}
