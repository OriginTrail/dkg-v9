# JPB Column-to-Ontology Mapping

This document records how the real JPB batch CSV exports from `dkg-manufacturing` map into the initial DMaaST ontology module in `packages/digital-twin`.

## Source files

- `AFFAIRE_202603271403.csv`
- `GAMME_202603271403.csv`
- `POINT_202603271403.csv`
- `CFRAIS_202603271403.csv`

## Current modeling scope

The current ontology slice is intentionally narrow, but now centered on a **single core production order** with linked views:

- core entity: `dmaast:ProductionOrder`
- order-facing view: `dmaast:OrderView`
- manufacturing-facing view: `dmaast:ManufacturingView`
- supporting records:
  - `GAMME` → `dmaast:RoutingDefinition`
  - `POINT` → `dmaast:ProductionStepEvent`
  - `CFRAIS` → `dmaast:OperationCode`

Status values used below:

- **Mapped now**: represented directly by the current ontology exports
- **Planned next**: expected to become ontology terms in the next ETL/ontology pass
- **Deferred**: documented but not yet modeled as first-class ontology terms

## Cross-dataset bridge keys

| CSV Field | Ontology term | Purpose |
|---|---|---|
| `NAF` | `dmaast:orderNo` | Primary JPB work-order / trace thread across AFFAIRE, GAMME, and POINT |
| `PARTNUMBER` | `dmaast:partNo` | Product / part linkage between AFFAIRE and GAMME |
| `COFRAIS` | `dmaast:operationCode` | Operation dictionary link between GAMME, POINT, and CFRAIS |

---

## AFFAIRE → `dmaast:OrderView` attached to `dmaast:ProductionOrder`

### Currently mapped columns

| CSV Column | Ontology term | Status | Notes |
|---|---|---|---|
| `NAF` | `dmaast:orderNo` | Mapped now | Main work order identifier |
| `PARTNUMBER` | `dmaast:partNo` | Mapped now | Ordered product / fitting part number |
| `MODELE` | `dmaast:productFamily` | Mapped now | Currently used as a compact family/model signal |
| `DESA` | `schema:description` | Planned next | Human-readable product description |
| `QTEAF` | `dmaast:orderedQuantity` | Mapped now | Ordered quantity |
| `DATEAF` | `dmaast:orderDate` | Mapped now | Order creation date |
| `DDP` | `dmaast:requestedDeliveryDate` | Mapped now | Requested delivery date |
| `DELAI` | `dmaast:productionDeadline` | Mapped now | Current production deadline/date target |
| `ETATAF` | `dmaast:orderStatus` | Mapped now | Work order status |

### Deferred AFFAIRE columns

All remaining AFFAIRE headers are currently documented as deferred for later ontology expansion:

`COCDE`, `COCLI`, `DESA2`, `DESA3`, `BLOCAGE`, `QTEAFREST`, `REM`, `REM2`, `COMON`, `PCONSTANT`, `TACLEUNIK`, `EXCLU`, `DELAIINIT`, `TYPEAF`, `NDEV`, `ACHETEUR`, `APPROVISIO`, `PREPARATOR`, `COACT`, `CODEEMP`, `REPRESENT1`, `TAUXREP1`, `REPRESENT2`, `TAUXREP2`, `DOSSIER`, `URGENCE`, `ASSQ`, `ADRLIV`, `ADRFAC`, `EDITDESA`, `QTEFAB`, `NBHR`, `OBS`, `OBSINTERNE`, `GRATUIT`, `FACT`, `POSTE`, `COEF`, `DTDEBPL`, `DELAIPL`, `DELAIINTER`, `DELAIATELIER`, `PLUSTARD`, `MODIFMAN`, `NUPL`, `INDPL`, `INDPCE`, `ECHANTILL`, `FLAG`, `NUMEXOTVA`, `MAGASIN`, `EstPDP`, `LIGNE`, `Couleur`, `GACLEUNIK`, `DATEORDOOLD`, `PTDECHARGEMENT`, `COFA`, `POIDS`, `POIDSNET`, `SOUS_FAI`, `ESTVISIBLE`, `DOSSIER2`, `FORCERAUPLUSTARD`, `DATEDEBUTPLUSTARD`, `RESPECTDELAI`, `DTDEBATELIER`, `DATEJALON`, `LIV_AFF_CADENCE`

Notes:

- several of these likely belong to future business-planning, logistics, or costing submodels
- `CODEEMP` may later link AFFAIRE ownership/preparation to operator/employee entities
- `POIDS` / `POIDSNET` are likely candidates for `qudt`-based mass terms

---

## GAMME → `dmaast:RoutingDefinition` attached to `dmaast:ManufacturingView`

### Currently mapped columns

| CSV Column | Ontology term | Status | Notes |
|---|---|---|---|
| `NAF` | `dmaast:orderNo` | Planned next | Needed when routing definitions are bound to a specific production order instance |
| `PARTNUMBER` | `dmaast:partNo` | Mapped now | Product or part the routing applies to |
| `PHASE` | `dmaast:phaseNumber` | Mapped now | Manufacturing phase number |
| `GA_DES` | `schema:description` | Planned next | Phase description / label |
| `COFRAIS` | `dmaast:operationCode` | Mapped now | Link to operation catalog |
| `GA_PREP` | `dmaast:setupTime` | Mapped now | Setup/prep time |
| `GA_NBH` | `dmaast:runTime` | Mapped now | Runtime estimate |
| `RANG` | `dmaast:operationSequence` | Planned next | Ordering or sub-sequence within routing |

### Deferred GAMME columns

All remaining GAMME headers are currently deferred:

`GACLEUNIK`, `ENCLEUNIK`, `GA_DES2`, `GA_DES3`, `GA_DES4`, `GA_DES5`, `GA_DES6`, `CAPEMPR`, `GA_NBHR`, `GA_PRES`, `GA_HRES`, `NBPIECE`, `OPFINIE`, `DAT`, `OPSECABLE`, `TYPEPLAN`, `VALEURPL`, `PHASEREF`, `TPSATTENTE`, `DATEMIN`, `DATEMAX`, `DEGREURGENCE`, `GA_NOMDOC`, `GA_IND_DOC`, `GA_NIVEAU`, `OBS`, `NACLEUNIK`, `DATEMODIF`, `OPERMODIF`, `BLOCAGE`, `RESIDMODIF`, `NBPERSTP`, `NBPERSTU`, `GROUPEMIN`, `GROUPEMAX`, `PostConso`, `GIS`, `DATEORDOOLD`, `OPE_ST`, `MODEIMPUTATION`, `INDGAMCTRL`, `TUAFFICH`, `QTEFAB`, `CODERGP`, `CODERGP1`, `ValeurSurfabrication`, `ModeSurfabrication`

Notes:

- many of these look like planning, staffing, or execution-control fields
- `NBPERSTP` / `NBPERSTU` may later justify workforce or capacity terms
- `OBS` is a candidate for annotation/comment modeling

---

## POINT → `dmaast:ProductionStepEvent` attached to `dmaast:ProductionOrder`

### Currently mapped columns

| CSV Column | Ontology term | Status | Notes |
|---|---|---|---|
| `IDPOINT` | `dmaast:eventId` | Mapped now | Event row identifier |
| `NAF` | `dmaast:orderNo` | Mapped now | Link back to AFFAIRE work order |
| `COFRAIS` | `dmaast:operationCode` | Mapped now | Operation performed |
| `CODEEMP` | `dmaast:operatorId` | Mapped now | Operator / employee code |
| `TPSPASSE` | `dmaast:duration` | Mapped now | Time spent |
| `DAT` | `dmaast:eventDate` | Mapped now | Event date |
| `DATEFIN` | `dmaast:endDate` | Mapped now | End date |
| `HEUREDEB` | `dmaast:startTime` | Mapped now | Start time |
| `HEUREFIN` | `dmaast:endTime` | Mapped now | End time |
| `NBPIE` | `dmaast:itemsProduced` | Mapped now | Produced piece count |
| `NBPIEABIME` | `dmaast:itemsDamaged` | Mapped now | Damaged piece count |

### Deferred POINT columns

Remaining POINT headers are currently deferred:

`GACLEUNIK`, `GA_PREP`, `FLAG`, `TAUXHOMME`, `TAUXMACHIN`, `O0CLEUNIK`, `TPSMASQUE`, `OBS`, `TYPEALEA`, `SVCLEUNIK`, `COSERVICE`, `CompteurGroupe`

Notes:

- `OBS` is likely useful as event annotation text
- `TAUXHOMME` / `TAUXMACHIN` may support performance/cost modeling later
- `COSERVICE` may be relevant for organizational provenance

---

## CFRAIS → `dmaast:OperationCode`

### Currently mapped columns

| CSV Column | Ontology term | Status | Notes |
|---|---|---|---|
| `IDCFRAIS` | `dmaast:eventId` | Planned next | May become a dedicated operation dictionary id term instead |
| `COFRAIS` | `dmaast:operationCode` | Mapped now | Canonical operation code |
| `DESIGN` | `schema:name` | Planned next | Human-readable operation label |

### Deferred CFRAIS columns

Remaining CFRAIS headers are currently deferred:

`COSECT`, `TAUXHOMMETP`, `TAUXHOMMETU`, `INPUT`, `POT`, `NBJSEM`, `TYPE`, `TEMPS`, `NUMER`, `COEF`, `FAM`, `CUMULPL`, `CUMUL`, `QTEPCE`, `LIBRETXT1`, `LIBRETXT2`, `LIBRETXT3`, `LIBRETXT4`, `LIBRETXT5`, `LIBRETXT6`, `LIBRETXT7`, `LIBRENUM1`, `LIBRENUM2`, `TYPCAL`, `PREFDOC`, `GA_OUTILL`, `COEFEFF`, `FLAG`, `NBPERSTP`, `NBPERSTU`, `PostConso`, `DATESO`, `ORDRE`, `COGROUPE`, `Couleur`, `EXCLU`, `UNITEGAMME`, `MODEIMPUTATION`, `TEMPSGEL`, `OPE_ST`, `NonPlanifiable`, `COMPETENCE`, `SEUIL_BAS`, `SEUIL_HAUT`, `SEUIL_RENTABILITE`, `RESSOURCE_CRITIQUE`, `EstMacroRessource`, `ModeSurfabrication`, `ValeurSurfabrication`, `TPP_DEFAUT`, `TPU_DEFAUT`, `ORDREBAC`

Notes:

- `COMPETENCE` and `RESSOURCE_CRITIQUE` look particularly relevant for later capability/resource ontology work
- rate and threshold fields likely belong to a separate operational-capacity extension

---

## Immediate ETL target shape

The current intended ETL target is:

- `AFFAIRE` provides the order-facing view of a production order
- `GAMME` provides routing definitions referenced by the manufacturing view
- `POINT` provides actual production-step execution events attached to the same production order
- `CFRAIS` provides the operation dictionary that labels `COFRAIS`

Minimal linked graph shape:

1. create one `dmaast:ProductionOrder` per JPB tracked order/item thread
2. create one `dmaast:OrderView` from AFFAIRE and link it with `dmaast:hasOrderView`
3. create one `dmaast:ManufacturingView` and link it with `dmaast:hasManufacturingView`
4. create one `dmaast:RoutingDefinition` per GAMME phase row and connect it from the manufacturing view with `dmaast:followsRoutingDefinition`
5. create one `dmaast:ProductionStepEvent` per POINT row and attach it to the production order with `dmaast:hasProductionStep`
6. create one `dmaast:OperationCode` per CFRAIS row and reference it from events with `dmaast:usesOperationCode`
7. join them through:
   - `dmaast:orderNo`
   - `dmaast:partNo`
   - `dmaast:operationCode`

## Next ontology expansion candidates

Highest-value next additions:

- `schema:description` / `schema:name` usage for JPB labels and comments
- dedicated identifier term for operation dictionary rows
- provenance terms for CSV source and ETL versioning
- planning/staffing/capacity terms from `GAMME` and `CFRAIS`
- weight, deadline, urgency, and workshop scheduling terms from `AFFAIRE`
