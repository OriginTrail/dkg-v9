# @origintrail-official/dkg-digital-twin

Digital-twin integration helpers for manufacturing ETL and publishing on DKG V10.

## Current scope

This package currently provides:

- parser, mapper, query, asset, and publishing contracts
- shared-memory and async-lift orchestration helpers
- an initial **DMaaST ontology module** derived from real example data in `dkg-manufacturing`

The ontology work started from the **JPB batch datasets** and is intended to become the target model for the `packages/digital-twin` ETL.

## Source data used for the first ontology pass

The initial ontology module was derived from the real JPB example data in the sibling `dkg-manufacturing` repository:

- `data/jpb/AFFAIRE_202603271403.csv` — work orders / customer-order-like demand records
- `data/jpb/GAMME_202603271403.csv` — routing and phase definitions
- `data/jpb/POINT_202603271403.csv` — execution tracking / production step events
- `data/jpb/CFRAIS_202603271403.csv` — operation code catalog

It also follows the documented DMaaST direction captured in:

- `dkg-manufacturing/project_documentation/DMaaST_Ontology_Mapping.md`

Detailed JPB column-by-column documentation lives in:

- `docs/jpb-column-mapping.md`

## DMaaST ontology module

Ontology exports live in:

- `src/dmaast-ontology.ts`

### Namespaces

The module exports the namespace map via `DMAAST_NAMESPACES`:

- `dmaast` → `https://dmaast.eu/ontology/`
- `schema` → `https://schema.org/`
- `prov` → `http://www.w3.org/ns/prov#`
- `qudt` → `http://qudt.org/schema/qudt/`
- `mason` → `http://www.owl-ontologies.com/mason.owl#`
- `gr` → `http://purl.org/goodrelations/v1#`
- `xsd` → `http://www.w3.org/2001/XMLSchema#`

### Core classes

The revised ontology direction centers on a **core production/work order** plus linked views:

- `dmaast:ProductionOrder` — central traceable thing
- `dmaast:OrderView` — customer/order-facing projection
- `dmaast:ManufacturingView` — manufacturing/routing-facing projection

The package also exports supporting classes needed for JPB batch ETL:

- `dmaast:RoutingDefinition`
- `dmaast:ProductionStepEvent`
- `dmaast:OperationCode`
- `dmaast:ValueChainEntity`
- `dmaast:ExpertKnowledge`

### Core properties

The initial exported DMaaST properties include:

- order and product identity
  - `dmaast:orderNo`
  - `dmaast:orderStatus`
  - `dmaast:partNo`
  - `dmaast:productFamily`
- quantity and scheduling
  - `dmaast:orderedQuantity`
  - `dmaast:orderDate`
  - `dmaast:requestedDeliveryDate`
  - `dmaast:productionDeadline`
- routing
  - `dmaast:phaseNumber`
  - `dmaast:operationCode`
  - `dmaast:setupTime`
  - `dmaast:runTime`
  - `dmaast:operationSequence`
  - `dmaast:phaseLabel`
- core/view relations
  - `dmaast:hasOrderView`
  - `dmaast:hasManufacturingView`
  - `dmaast:hasProductionStep`
- execution events
  - `dmaast:eventId`
  - `dmaast:operatorId`
  - `dmaast:duration`
  - `dmaast:eventDate`
  - `dmaast:startTime`
  - `dmaast:endDate`
  - `dmaast:endTime`
  - `dmaast:itemsProduced`
  - `dmaast:itemsDamaged`
- provenance and linkage
  - `dmaast:sourceSystem`
  - `dmaast:sourceTable`
  - `dmaast:followsRoutingDefinition`
  - `dmaast:usesOperationCode`
  - `dmaast:confidenceLevel`

### Bridge keys

For the JPB batch model, the current bridge keys are:

- `dmaast:orderNo`
- `dmaast:partNo`
- `dmaast:operationCode`

These are exported in `DMAAST_JPB_CORE_MODEL.bridgeKeys`.

### Core/view relations

The current intended graph shape is:

- `dmaast:ProductionOrder` `dmaast:hasOrderView` `dmaast:OrderView`
- `dmaast:ProductionOrder` `dmaast:hasManufacturingView` `dmaast:ManufacturingView`
- `dmaast:ProductionOrder` `dmaast:hasProductionStep` `dmaast:ProductionStepEvent`
- `dmaast:ProductionStepEvent` `dmaast:usesOperationCode` `dmaast:OperationCode`
- `dmaast:ManufacturingView` `dmaast:followsRoutingDefinition` `dmaast:RoutingDefinition`

## Dataset mapping

The module exports a compact dataset model in `DMAAST_JPB_CORE_MODEL`.

Current mapping:

- `AFFAIRE` → `dmaast:OrderView` attached to `dmaast:ProductionOrder`
- `GAMME` → `dmaast:RoutingDefinition` attached to `dmaast:ManufacturingView`
- `POINT` → `dmaast:ProductionStepEvent` attached to `dmaast:ProductionOrder`
- `CFRAIS` → `dmaast:OperationCode`

Each dataset entry includes:

- target class IRI
- short description
- key CSV fields used to anchor ETL mapping

## Usage

### Use a term directly

```ts
import { dmaastTerm } from '@origintrail-official/dkg-digital-twin';

const orderNo = dmaastTerm('orderNo');
// https://dmaast.eu/ontology/orderNo
```

### Reuse the JSON-LD context

```ts
import { dmaastJsonLdContext } from '@origintrail-official/dkg-digital-twin';

const context = dmaastJsonLdContext();
```

### Inspect dataset-to-class mappings

```ts
import { DMAAST_JPB_CORE_MODEL } from '@origintrail-official/dkg-digital-twin';

const pointClass = DMAAST_JPB_CORE_MODEL.datasets.point.classIri;
```

## Design notes

- This is an **initial ontology slice**, not the full DMaaST ontology.
- It is intentionally centered on the first JPB ETL target because those datasets are available and concrete.
- The package reuses the documented `dmaast:` namespace and common vocabularies (`schema`, `prov`, `qudt`, `mason`, `gr`) rather than inventing a separate model.
- The current ontology direction treats order-facing and manufacturing-facing data as **different views of the same production order**, rather than as unrelated entities.
- The next step is to map ETL outputs from `AFFAIRE`, `GAMME`, `POINT`, and `CFRAIS` into RDF/JSON-LD using these exported terms.

## Validation

The ontology module is covered by:

- `test/dmaast-ontology.test.ts`

Run:

```bash
pnpm exec vitest run test/dmaast-ontology.test.ts
```
