export interface DigitalTwinRow {
  sourceTable: string;
  values: Record<string, unknown>;
}

export interface DigitalTwinNode {
  '@id'?: string;
  '@type'?: string | string[];
  [key: string]: unknown;
}

export interface DigitalTwinQuad {
  subject: string;
  predicate: string;
  object: string;
  graph?: string;
}

export interface DigitalTwinAsset {
  rootEntity: string;
  quads: DigitalTwinQuad[];
}

export interface ParserContext {
  dataset: string;
  sourceFile?: string;
}

export interface ParseResult<TRow = DigitalTwinRow> {
  rows: TRow[];
  errors?: string[];
}

export interface Parser<TInput = unknown, TRow = DigitalTwinRow> {
  parse(input: TInput, context: ParserContext): Promise<ParseResult<TRow>> | ParseResult<TRow>;
}

export interface MapperContext {
  dataset: string;
}

export interface Mapper<TRow = DigitalTwinRow, TNode = DigitalTwinNode> {
  map(row: TRow, context: MapperContext): Promise<TNode> | TNode;
}

export interface PublishOptions {
  paranetId?: string;
  accessPolicy?: 'public' | 'ownerOnly' | 'allowList';
  allowedPeers?: string[];
}

export interface PublishResult {
  ual: string;
  kcId: string;
  status: string;
}

export interface Publisher<TNode = DigitalTwinNode> {
  publish(node: TNode, options?: PublishOptions): Promise<PublishResult>;
}

export interface AssetContext {
  dataset: string;
  contextGraphId: string;
}

export interface AssetBuilder<TNode = DigitalTwinNode> {
  build(node: TNode, context: AssetContext): Promise<DigitalTwinAsset> | DigitalTwinAsset;
}

export interface SharedMemoryPublishOptions {
  publisherPeerId: string;
  subGraphName?: string;
}

export interface SharedMemoryPublishResult {
  shareOperationId: string;
}

export interface SharedMemoryPublisher {
  share(
    contextGraphId: string,
    quads: DigitalTwinQuad[],
    options: SharedMemoryPublishOptions,
  ): Promise<SharedMemoryPublishResult>;
}

export type LiftTransitionType = 'CREATE' | 'UPDATE' | 'DELETE';

export interface LiftAuthorityProof {
  type: string;
  proofRef: string;
}

export interface LiftRequest {
  swmId: string;
  shareOperationId: string;
  roots: readonly string[];
  contextGraphId: string;
  namespace: string;
  scope: string;
  transitionType: LiftTransitionType;
  authority: LiftAuthorityProof;
  priorVersion?: string;
}

export interface AsyncLiftPublisher {
  lift(request: LiftRequest): Promise<string>;
}

export interface LiftContext {
  dataset: string;
  contextGraphId: string;
  swmId: string;
  namespace: string;
  scope: string;
  transitionType: LiftTransitionType;
  authority: LiftAuthorityProof;
  publisherPeerId: string;
  priorVersion?: string;
  subGraphName?: string;
}

export interface SharedBatch {
  shareOperationId: string;
  roots: string[];
  quads: DigitalTwinQuad[];
}

export interface WorkingMemoryContext {
  contextGraphId: string;
  publisherPeerId: string;
  subGraphName?: string;
}

export interface WorkingMemoryQueryContext extends QueryContext {
  graphIri: string;
}

export interface QueryExecutionContext<TResult = unknown> extends WorkingMemoryQueryContext {
  runner: QueryRunner<TResult>;
}

export interface LiftedBatch extends SharedBatch {
  jobId: string;
  request: LiftRequest;
}

export interface QueryContext {
  dataset: string;
  paranetId?: string;
}

export interface Query<TParams = Record<string, unknown>> {
  build(params: TParams, context: QueryContext): string;
}

export interface QueryRunner<TResult = unknown> {
  query(sparql: string, context: QueryContext): Promise<TResult>;
}
