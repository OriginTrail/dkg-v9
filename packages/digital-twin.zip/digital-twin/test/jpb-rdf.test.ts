import { describe, expect, it } from 'vitest';
import {
  mapAffaireRowToAsset,
  mapCfraisRowToAsset,
  mapGammeRowToAsset,
  mapPointRowToAsset,
} from '../src/index.js';

const affaire44671 = {
  NAF: '44671',
  PARTNUMBER: 'ST5363-07',
  MODELE: '21',
  DESA: 'LULYLOK',
  QTEAF: '500.000000',
  DATEAF: '2023-10-09',
  DDP: '2024-06-19',
  DELAI: '2024-03-01',
  ETATAF: 'S',
};

const gamme44671 = {
  NAF: '44671',
  RANG: '001',
  PARTNUMBER: 'ST5363-07',
  PHASE: '50',
  GA_DES: 'Sabler',
  COFRAIS: 'SABL',
  GA_PREP: '0.333333',
  GA_NBH: '5.555500',
};

const point44671 = {
  IDPOINT: '246474',
  CODEEMP: 'XAV',
  TPSPASSE: '0.116667',
  DAT: '2024-03-05',
  COFRAIS: '1CTRL',
  NAF: '44671',
  NBPIE: '18.000000',
  NBPIEABIME: '0.000000',
  DATEFIN: '2024-03-05',
  HEUREDEB: '19:00:00',
  HEUREFIN: '19:07:00',
};

const cfraisSabl = {
  IDCFRAIS: '156',
  COFRAIS: 'SABL',
  DESIGN: 'SABLAGE & MASQUAGE',
};

describe('JPB RDF mapping helpers', () => {
  it('maps AFFAIRE rows to a ProductionItem asset', () => {
    const asset = mapAffaireRowToAsset(affaire44671);

    expect(asset.rootEntity).toBe('urn:dmaast:jpb:production-item:44671');
    expect(asset.quads).toContainEqual({
      subject: 'urn:dmaast:jpb:production-item:44671',
      predicate: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
      object: 'https://dmaast.eu/ontology/ProductionItem',
      graph: '',
    });
    expect(asset.quads).toContainEqual({
      subject: 'urn:dmaast:jpb:production-item:44671',
      predicate: 'https://dmaast.eu/ontology/orderNo',
      object: '"44671"',
      graph: '',
    });
  });

  it('maps GAMME rows to routing definitions linked from the production item', () => {
    const asset = mapGammeRowToAsset(gamme44671);

    expect(asset.rootEntity).toBe('urn:dmaast:jpb:production-item:44671');
    expect(asset.quads).toContainEqual({
      subject: 'urn:dmaast:jpb:production-item:44671',
      predicate: 'https://dmaast.eu/ontology/followsRoutingDefinition',
      object: 'urn:dmaast:jpb:routing:44671:50:SABL',
      graph: '',
    });
    expect(asset.quads).toContainEqual({
      subject: 'urn:dmaast:jpb:routing:44671:50:SABL',
      predicate: 'https://dmaast.eu/ontology/phaseNumber',
      object: '"50"^^<http://www.w3.org/2001/XMLSchema#integer>',
      graph: '',
    });
  });

  it('maps POINT rows to production-step events linked from the production item', () => {
    const asset = mapPointRowToAsset(point44671);

    expect(asset.rootEntity).toBe('urn:dmaast:jpb:production-item:44671');
    expect(asset.quads).toContainEqual({
      subject: 'urn:dmaast:jpb:production-item:44671',
      predicate: 'https://dmaast.eu/ontology/hasProductionStep',
      object: 'urn:dmaast:jpb:production-step:246474',
      graph: '',
    });
    expect(asset.quads).toContainEqual({
      subject: 'urn:dmaast:jpb:production-step:246474',
      predicate: 'https://dmaast.eu/ontology/usesOperationCode',
      object: 'urn:dmaast:jpb:operation-code:1CTRL',
      graph: '',
    });
  });

  it('maps CFRAIS rows to operation-code dictionary assets', () => {
    const asset = mapCfraisRowToAsset(cfraisSabl);

    expect(asset.rootEntity).toBe('urn:dmaast:jpb:operation-code:SABL');
    expect(asset.quads).toContainEqual({
      subject: 'urn:dmaast:jpb:operation-code:SABL',
      predicate: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
      object: 'https://dmaast.eu/ontology/OperationCode',
      graph: '',
    });
    expect(asset.quads).toContainEqual({
      subject: 'urn:dmaast:jpb:operation-code:SABL',
      predicate: 'https://schema.org/name',
      object: '"SABLAGE & MASQUAGE"',
      graph: '',
    });
  });
});
