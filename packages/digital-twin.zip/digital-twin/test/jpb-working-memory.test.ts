import { describe, expect, it, vi } from 'vitest';
import { defineProductionItemWorkspaceQuery, shareJpbRowsWith } from '../src/index.js';

const affaire44671 = {
  NAF: '44671',
  PARTNUMBER: 'ST5363-07',
  MODELE: '21',
  DESA: 'LULYLOK',
  QTEAF: '500.000000',
  DATEAF: '2023-10-09',
  DDP: '2024-06-19',
  DELAI: '2024-03-01',
  ETATAF: 'S',
};

const gamme44671 = {
  NAF: '44671',
  RANG: '001',
  PARTNUMBER: 'ST5363-07',
  PHASE: '50',
  GA_DES: 'Sabler',
  COFRAIS: 'SABL',
  GA_PREP: '0.333333',
  GA_NBH: '5.555500',
};

const point44671 = {
  IDPOINT: '246474',
  CODEEMP: 'XAV',
  TPSPASSE: '0.116667',
  DAT: '2024-03-05',
  COFRAIS: '1CTRL',
  NAF: '44671',
  NBPIE: '18.000000',
  NBPIEABIME: '0.000000',
  DATEFIN: '2024-03-05',
  HEUREDEB: '19:00:00',
  HEUREFIN: '19:07:00',
};

const cfraisSabl = {
  IDCFRAIS: '156',
  COFRAIS: 'SABL',
  DESIGN: 'SABLAGE & MASQUAGE',
};

describe('JPB working-memory helpers', () => {
  it('shares mapped JPB rows into working memory through the shared publisher', async () => {
    const share = vi.fn(async () => ({ shareOperationId: 'swm-jpb-1' }));

    const result = await shareJpbRowsWith(
      { share },
      {
        affaire: [affaire44671],
        gamme: [gamme44671],
        point: [point44671],
        cfrais: [cfraisSabl],
      },
      { contextGraphId: 'jpb-demo', publisherPeerId: 'peer-jpb' },
    );

    expect(share).toHaveBeenCalledTimes(1);
    expect(result.shareOperationId).toBe('swm-jpb-1');
    expect(result.roots).toEqual([
      'urn:dmaast:jpb:production-item:44671',
      'urn:dmaast:jpb:operation-code:SABL',
    ]);
    expect(result.quads.some((quad) => quad.predicate === 'https://dmaast.eu/ontology/hasProductionStep')).toBe(true);
    expect(result.quads.some((quad) => quad.predicate === 'https://dmaast.eu/ontology/followsRoutingDefinition')).toBe(true);
  });

  it('builds a workspace query that pulls the production item, steps, and routing by order number', () => {
    const query = defineProductionItemWorkspaceQuery();
    const sparql = query.build(
      { orderNo: '44671' },
      { dataset: 'jpb', graphIri: 'did:dkg:context-graph:jpb/_workspace' },
    );

    expect(sparql).toContain('GRAPH <did:dkg:context-graph:jpb/_workspace>');
    expect(sparql).toContain('<https://dmaast.eu/ontology/ProductionItem>');
    expect(sparql).toContain('<https://dmaast.eu/ontology/orderNo> "44671"');
    expect(sparql).toContain('<https://dmaast.eu/ontology/hasProductionStep>');
    expect(sparql).toContain('<https://dmaast.eu/ontology/followsRoutingDefinition>');
  });
});
